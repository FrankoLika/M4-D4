var arrayLibri = [];
document.addEventListener("DOMContentLoaded", async () => {
    await fetch(`https://striveschool-api.herokuapp.com/books`).then((response) => {
        response.json().then((dati) => {
            arrayLibri = dati;
            cards(arrayLibri);
        })
    }).catch((err) => {
        console.log("errore = " + err);
    })
})


document.getElementById("home").addEventListener("click", () => {
    let cont = document.getElementById("cont");
    cont.innerHTML = "";
    cards(arrayLibri);
})


function cards(arr) {
    arr.forEach((item, i) => {

        let cont = document.getElementById("cont");

        let col = document.createElement("div");
        col.className = "col";
        col.id = "col_" + i;


        let card = document.createElement("div");
        card.id = "card_" + i;
        card.className = "card shadow-sm";
        card.style.width = "15rem";


        let a = document.createElement("a");
        a.innerText = item.title;
        a.href = "/Esercizio4/prodotto.html?asin=" + item.asin;
        a.className = "card-title text-center";
        a.style.height = "90px";


        let contImg = document.createElement("div");
        contImg.className = "d-flex justify-content-center"
        contImg.style.height = "240px"
        let img = document.createElement("img");
        img.src = item.img;
        img.style.width = "150px"
        img.style.borderRadius = "6px"

        let cardBody = document.createElement("div");
        cardBody.className = "card-body";

        let pDescription = document.createElement("p");
        pDescription.className = "card-text";

        let divBottom = document.createElement("div");
        divBottom.className = "d-flex justify-content-between align-items-center"

        let divBtns = document.createElement("div");
        divBtns.className = "btn-group";

        let divCategory = document.createElement("div");
        divCategory.className = "card-text"
        divCategory.style.marginTop = "-20px"
        divCategory.innerText = "Categoria : " + item.category;

        let divPrice = document.createElement("div");
        divPrice.className = "card-text"
        divPrice.innerText = "Prezzo : " + item.price + "€";
        divPrice.style.marginBottom = "8px";

        let btn1 = document.createElement("button");
        btn1.id = "btn1_" + i;
        btn1.innerText = "Add To Cart"
        btn1.style.border = "0"
        btn1.style.borderRadius = "5px";
        btn1.onclick = () => {
            if (btn1.innerText === "Add To Cart") {
                btn1.style.display = "none"
                btn2.style.display = "none"
                card.style.backgroundColor = "#03AF1D"
            }
            let title = item.title;
            let price = item.price;
            let indice = i;
            tabellaCart(title, price, indice)
        }


        let btn2 = document.createElement("button");
        btn2.id = "btn2_" + i;
        btn2.style.marginLeft = "65px";
        btn2.innerText = "Skip";
        btn2.style.border = "0";
        btn2.style.borderRadius = "5px";
        btn2.onclick = () => {
            document.getElementById("col_" + i).classList.add("d-none");
        }

        divBtns.append(btn1, btn2)
        divBottom.appendChild(divBtns);

        cardBody.append(pDescription, divCategory, divPrice, divBottom);

        contImg.appendChild(img);
        card.append(a, contImg, cardBody)
        col.appendChild(card);
        cont.appendChild(col);
    })
}

function tabellaCart(title, price, i) {
    let tr = document.createElement("tr");
    tr.id = "tr" + i;

    let tdTitle = document.createElement("td");
    tdTitle.innerText = title;
    tdTitle.id = "titolo" + i;

    let tdPrice = document.createElement("td");
    tdPrice.innerText = price + "€";

    let tdDelete = document.createElement("td");
    let btnDelete = document.createElement("button");
    btnDelete.id = "delete_" + i;
    btnDelete.style.border = "0";
    btnDelete.style.backgroundColor = "transparent";
    let img = document.createElement("img");
    img.setAttribute("src", "assets/trash-2.svg");

    btnDelete.appendChild(img);
    tdDelete.appendChild(btnDelete);

    tr.append(tdTitle, tdPrice, tdDelete);
    document.getElementById("tBody").appendChild(tr);

    btnDelete.onclick = () => {
        document.getElementById("tr" + i).classList.add("d-none");
        document.getElementById("card_" + i).style.backgroundColor = "transparent";
        document.getElementById("btn1_"+i).style.removeProperty("display");
        document.getElementById("btn2_"+i).style.removeProperty("display");
        tot.splice(i, 1, 0);
        if (tot.length === 0) {
            document.getElementById("totale").innerText = "...";
        } else {
            document.getElementById("totale").innerText = tot.reduce(reduce) + "€";
        }
    }
    totale(price);
}

var tot = [];

function totale(price) {
    tot.push(price);

    document.getElementById("totale").innerText = tot.reduce(reduce) + "€";
}
function reduce(total, num) {
    return total + num;
}


async function cercaLibro() {
    let arrFiltrato = [];
    let valoreCercato = document.getElementById("search").value;
    if (valoreCercato.length > 3) {
        fetch("https://striveschool-api.herokuapp.com/books/?title=" + valoreCercato).then((response) => {
            response.json().then((data) => {
                arrFiltrato = data
                let cont = document.getElementById("cont");
                cont.innerHTML = "";
                cards(arrFiltrato);
            })
        })
    }
}


document.getElementById("emptyCart").addEventListener("click", () => {
    document.getElementById("tBody").innerHTML = "";
})



